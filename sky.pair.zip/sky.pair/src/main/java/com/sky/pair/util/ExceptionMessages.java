package com.sky.pair.util;

/**
 * Created by cipriach on 06.10.2016.
 */
public class ExceptionMessages {
    public static final String INVALID_TECHNICAL_ACCOUNT_NUMBER = "The account number is invalid";
}
