package com.sky.pair.service;

import com.sky.pair.exceptions.InvalidAccountNumberException;
import com.sky.pair.exceptions.TechnicalFailureException;
import com.sky.pair.util.CustomerEligibility;
import com.sky.pair.util.ExceptionMessages;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class EligibilityService {

    public CustomerEligibility checkEligibility(String accountNumber) {
        if(StringUtils.isEmpty(accountNumber)) {
            throw new InvalidAccountNumberException(ExceptionMessages.INVALID_TECHNICAL_ACCOUNT_NUMBER);
        }
        if (accountNumber.equals("a1")) {
            return CustomerEligibility.CUSTOMER_ELIGIBLE;
        }
        if (accountNumber.equals("p1")) {
            return CustomerEligibility.CUSTOMER_INELIGIBLE;
        }
        if (accountNumber.equals("t1")) {
            throw new TechnicalFailureException();
        }
        return null;
    }
}
