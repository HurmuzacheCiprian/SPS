package com.sky.pair.service;

import com.sky.pair.util.Channel;
import com.sky.pair.util.RewardsResponse;

import java.util.List;

public interface RewardsService {
    RewardsResponse getRewards(String accountNumber, List<Channel> channels);
}
