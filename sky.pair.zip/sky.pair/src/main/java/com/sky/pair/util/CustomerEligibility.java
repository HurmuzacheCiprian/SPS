package com.sky.pair.util;

/**
 * Created by cipriach on 06.10.2016.
 */
public enum CustomerEligibility {
    CUSTOMER_ELIGIBLE,
    CUSTOMER_INELIGIBLE
}
