package com.sky.pair.service;


import com.sky.pair.exceptions.InvalidAccountNumberException;
import com.sky.pair.exceptions.TechnicalFailureException;
import com.sky.pair.util.Channel;
import com.sky.pair.util.CustomerEligibility;
import com.sky.pair.util.Rewards;
import com.sky.pair.util.RewardsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class RewardsServiceImpl implements RewardsService {

    @Autowired
    private EligibilityService eligibilityService;

    @Override
    public RewardsResponse getRewards(String accountNumber, List<Channel> channels) {
        CustomerEligibility customerEligibility;
        try {
            customerEligibility = eligibilityService.checkEligibility(accountNumber);
        } catch(InvalidAccountNumberException ex) {
            return RewardsResponse.builder().rewards(Collections.emptyList()).message(ex.getMessage()).build();
        } catch (TechnicalFailureException ex) {
            return RewardsResponse.builder().rewards(Collections.emptyList()).build();
        }

        if (customerEligibility == CustomerEligibility.CUSTOMER_ELIGIBLE) {
            return RewardsResponse.builder().rewards(createRewards(channels)).build();
        }
        return RewardsResponse.builder().rewards(Collections.emptyList()).build();
    }

    private List<Rewards> createRewards(List<Channel> channels) {
        final List<Rewards> rewards = new ArrayList<>(3);
        for (Channel channel : channels) {
            if (channel == Channel.SPORTS) {
                rewards.add(Rewards.CHAMPIONS_LEAGUE_FINAL_TICKET);
            }
            if (channel == Channel.MOVIES) {
                rewards.add(Rewards.PIRATES_OF_THE_CARIBBEAN_COLLECTION);
            }
            if (channel == Channel.MUSIC) {
                rewards.add(Rewards.KARAOKE_PRO_MICROPHONE);
            }
        }

        return rewards;
    }


}
