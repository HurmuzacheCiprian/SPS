package com.sky.pair.exceptions;


public class InvalidAccountNumberException extends RuntimeException {
    public InvalidAccountNumberException(String messasge) {
        super(messasge);
    }
}
