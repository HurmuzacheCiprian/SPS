package com.sky.pair.util;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Builder
@Getter
public class RewardsResponse {
    private List<Rewards> rewards;
    private String message;
}
