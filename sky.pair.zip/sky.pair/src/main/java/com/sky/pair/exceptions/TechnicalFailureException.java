package com.sky.pair.exceptions;

/**
 * Created by cipriach on 06.10.2016.
 */
public class TechnicalFailureException extends RuntimeException {
}
