package com.sky.pair.resource;

import com.sky.pair.service.RewardsService;
import com.sky.pair.util.Channel;
import com.sky.pair.util.RewardsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/rewards")
public class RewardsResource {

    @Autowired
    private RewardsService rewardsService;

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<RewardsResponse> getRewards(@RequestParam("channelSubscriptions") List<Channel> channels,
                                                      @RequestParam("accountNumber") String accountNumber) {
        return new ResponseEntity<>(rewardsService.getRewards(accountNumber, channels), HttpStatus.OK);
    }


}
