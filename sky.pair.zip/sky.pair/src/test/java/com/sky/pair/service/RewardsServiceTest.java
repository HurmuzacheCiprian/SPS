package com.sky.pair.service;

import com.sky.pair.util.Channel;
import com.sky.pair.util.ExceptionMessages;
import com.sky.pair.util.Rewards;
import com.sky.pair.util.RewardsResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RewardsServiceTest {

    @Autowired
    private EligibilityService eligibilityService;

    @Autowired
    private RewardsService rewardsService;

    @Test
    public void shouldReturnChampionsLeagueRewardIfTheAccountIsEligibleAndHasTheSportsChannelSubscription() {
        RewardsResponse rewards = rewardsService.getRewards("a1", Arrays.asList(Channel.SPORTS));
        Assert.isTrue(rewards.getRewards() != null);
        Assert.isTrue(!rewards.getRewards().isEmpty());
        Assert.isTrue(rewards.getRewards().size() == 1);
    }

    @Test
    public void shouldReturnNoRewardsIfTheAccountIsEligibleAndHasKidsChannelSubscription() {
        RewardsResponse rewards = rewardsService.getRewards("a1", Arrays.asList(Channel.KIDS));
        Assert.isTrue(rewards.getRewards() != null && rewards.getRewards().isEmpty());
    }

    @Test
    public void shouldReturnOnlyTheChampionsLeagueRewardIfTheAccountHasTheSportsAndKidsChannelSubscriptions() {
        RewardsResponse rewards = rewardsService.getRewards("a1", Arrays.asList(Channel.KIDS, Channel.SPORTS));
        Assert.isTrue(rewards.getRewards() != null && rewards.getRewards().size() == 1);
    }

    @Test
    public void shouldReturnAllRewardsIfTheAccountIsEligibleAndHasSportsMoviesMusicChannelSubscriptions() {
        RewardsResponse response = rewardsService.getRewards("a1", Arrays.asList(Channel.SPORTS, Channel.KIDS, Channel.MOVIES, Channel.MUSIC));
        List<Rewards> rewards = response.getRewards();
        Assert.isTrue(rewards != null && rewards.size() == 3);
        Assert.isTrue(rewards.get(0) == Rewards.CHAMPIONS_LEAGUE_FINAL_TICKET);
        Assert.isTrue(rewards.get(1) == Rewards.PIRATES_OF_THE_CARIBBEAN_COLLECTION);
        Assert.isTrue(rewards.get(2) == Rewards.KARAOKE_PRO_MICROPHONE);

        Assert.isTrue(response.getMessage()== null);
    }

    @Test
    public void shouldThrowTechnicalFailureExceptionIfTheEligibilityServiceIsDown() {
        RewardsResponse rewards = rewardsService.getRewards("t1", Arrays.asList(Channel.SPORTS, Channel.MOVIES, Channel.MUSIC));
        Assert.isTrue(rewards.getRewards().isEmpty());
    }

    @Test
    public void shouldReturnNoRewardsAndShouldNotifyTheClientThatTheAccountNumberIsInvalid() {
        RewardsResponse rewardsResponse = rewardsService.getRewards(null, Arrays.asList(Channel.SPORTS, Channel.MOVIES, Channel.MUSIC));
        Assert.isTrue(rewardsResponse.getRewards() != null && rewardsResponse.getRewards().isEmpty());
        Assert.isTrue(rewardsResponse.getMessage().equals(ExceptionMessages.INVALID_TECHNICAL_ACCOUNT_NUMBER));
    }

}
