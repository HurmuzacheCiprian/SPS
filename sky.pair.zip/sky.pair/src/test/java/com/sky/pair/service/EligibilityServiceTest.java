package com.sky.pair.service;

import com.sky.pair.exceptions.InvalidAccountNumberException;
import com.sky.pair.exceptions.TechnicalFailureException;
import com.sky.pair.util.CustomerEligibility;
import com.sky.pair.util.ExceptionMessages;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class EligibilityServiceTest {

    @Autowired
    private EligibilityService eligibilityService;

    @Test
    public void shouldReturnCustomerEligibleWhenTheAccountNumberIsEligible() {
        Assert.assertTrue(eligibilityService.checkEligibility("a1") == CustomerEligibility.CUSTOMER_ELIGIBLE);
    }

    @Test
    public void shouldReturnCustomerNotEligibleWhenTheAccountNumberIsIneligible() {
        Assert.assertTrue(eligibilityService.checkEligibility("p1") == CustomerEligibility.CUSTOMER_INELIGIBLE);
    }

    @Test(expected = TechnicalFailureException.class)
    public void shouldThrowTechnicalExceptionWhenTheTechnicalServiceFailedToCheckTheAccountNumber() {
        eligibilityService.checkEligibility("t1");
    }

    @Test(expected = InvalidAccountNumberException.class)
    public void shouldThrowInvalidAccountNumberExceptionWhenTheAccountNumberIsNull() {
        eligibilityService.checkEligibility(null);
    }

    @Test
    public void shouldThrowInvalidAccountNumberExceptionWithErrorMessageWhenTheAccountNumberIsNull() {
        try {
            eligibilityService.checkEligibility("");
        } catch (InvalidAccountNumberException ex) {
            Assert.assertTrue(ex.getMessage().equals(ExceptionMessages.INVALID_TECHNICAL_ACCOUNT_NUMBER));
        }
    }

}
